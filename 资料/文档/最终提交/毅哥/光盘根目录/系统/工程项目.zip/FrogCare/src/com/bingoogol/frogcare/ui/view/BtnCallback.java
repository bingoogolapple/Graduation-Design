package com.bingoogol.frogcare.ui.view;

public interface BtnCallback {
	public void onClickLeft();

	public void onClickRight();
}
