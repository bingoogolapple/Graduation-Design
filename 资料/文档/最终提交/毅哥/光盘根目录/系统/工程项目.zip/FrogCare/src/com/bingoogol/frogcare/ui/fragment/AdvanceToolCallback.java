package com.bingoogol.frogcare.ui.fragment;

public interface AdvanceToolCallback {
	public void changeFragment(int toolType);
}
