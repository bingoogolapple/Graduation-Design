package com.bingoogol.frogcare.receiver;

import android.app.admin.DeviceAdminReceiver;

public class MyAdminReceiver extends DeviceAdminReceiver {
}
