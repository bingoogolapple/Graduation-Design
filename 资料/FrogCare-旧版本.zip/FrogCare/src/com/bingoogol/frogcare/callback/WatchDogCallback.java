package com.bingoogol.frogcare.callback;

public interface WatchDogCallback {
	public void addTempStopProtectPackageName(String packageName);
}
