package com.bingoogol.frogcare.ui.view;

public interface BtnCallback {
	public void onClickOk();

	public void onClickCancel();
}
